# Quantum Mechanics Proof Demonstrator
# Run this script in Visual Studio Code
# Requirements: pip install numpy matplotlib qiskit qutip

import numpy as np
import matplotlib.pyplot as plt
from qiskit import QuantumCircuit, transpile
from qiskit_aer import Aer
from qiskit.visualization import plot_bloch_vector
from qutip import sigmax, sigmay, sigmaz, expect, Qobj

# --- DOUBLE-SLIT EXPERIMENT (Wave-Particle Duality) ---
def simulate_double_slit():
    screen_distance = 1.0
    wavelength = 500e-9
    slit_distance = 1e-4
    num_particles = 1000
    screen_width = 0.02
    num_bins = 200

    screen_positions = np.linspace(-screen_width / 2, screen_width / 2, num_bins)
    intensity = np.zeros_like(screen_positions)

    for i, x in enumerate(screen_positions):
        path_diff = (x + slit_distance / 2)**2 - (x - slit_distance / 2)**2
        path_diff /= (2 * screen_distance)
        phase_diff = 2 * np.pi * path_diff / wavelength
        intensity[i] = (np.cos(phase_diff / 2))**2

    probabilities = intensity / np.sum(intensity)
    hits = np.random.choice(screen_positions, size=num_particles, p=probabilities)

    plt.figure(figsize=(10, 4))
    plt.hist(hits, bins=num_bins, range=(-screen_width/2, screen_width/2), color='blue', alpha=0.7)
    plt.title("Double-Slit Simulation (Wave-Particle Duality)")
    plt.xlabel("Screen Position (m)")
    plt.ylabel("Particle Hits")
    plt.grid(True)
    plt.show()

# --- QUANTUM SUPERPOSITION (Bloch Sphere) ---
def demonstrate_superposition():
    qc = QuantumCircuit(1)
    qc.h(0)  # Hadamard gate creates superposition
    simulator = Aer.get_backend('statevector_simulator')
    compiled = transpile(qc, simulator)
    result = simulator.run(compiled).result()
    statevector = result.get_statevector()

    sx = expect(sigmax(), Qobj(statevector))
    sy = expect(sigmay(), Qobj(statevector))
    sz = expect(sigmaz(), Qobj(statevector))

    bloch = [np.real(sx), np.real(sy), np.real(sz)]
    plot_bloch_vector(bloch, title="Qubit in Superposition (|+⟩)")
    plt.show()

# --- ENTANGLEMENT (Bell State) ---
def demonstrate_entanglement():
    qc = QuantumCircuit(2)
    qc.h(0)
    qc.cx(0, 1)
    qc.measure_all()
    simulator = Aer.get_backend('qasm_simulator')
    job = simulator.run(transpile(qc, simulator), shots=1024)
    counts = job.result().get_counts()

    plt.figure(figsize=(6, 4))
    plt.bar(counts.keys(), counts.values(), color='purple')
    plt.title("Bell State Entanglement (Measurement Correlation)")
    plt.xlabel("Measurement Outcome")
    plt.ylabel("Counts")
    plt.grid(True)
    plt.show()

# --- QUANTUM TUNNELING (Barrier Penetration) ---
def simulate_tunneling():
    N = 200
    x = np.linspace(-1, 1, N)
    dx = x[1] - x[0]
    V = np.zeros(N)
    V[N//2-10:N//2+10] = 100

    H = -2*np.diag(np.ones(N)) + np.diag(np.ones(N-1), 1) + np.diag(np.ones(N-1), -1)
    H = (-1/(2*dx**2))*H + np.diag(V)

    psi0 = np.exp(-100 * (x + 0.5)**2)
    psi0 /= np.sqrt(np.sum(np.abs(psi0)**2))

    E, psi = np.linalg.eigh(H)
    coeffs = np.dot(np.conj(psi.T), psi0)
    psi_t = np.dot(psi, coeffs * np.exp(-1j * E * 0.05))

    plt.figure(figsize=(10, 4))
    plt.plot(x, np.abs(psi_t)**2, label='|ψ|²')
    plt.plot(x, V / np.max(V) * np.max(np.abs(psi_t)**2), '--', label='Barrier')
    plt.title("Quantum Tunneling Through Barrier")
    plt.xlabel("Position")
    plt.ylabel("Probability Density")
    plt.legend()
    plt.grid(True)
    plt.show()

# === RUN ALL DEMONSTRATIONS ===
if __name__ == "__main__":
    simulate_double_slit()
    demonstrate_superposition()
    demonstrate_entanglement()
    simulate_tunneling()
