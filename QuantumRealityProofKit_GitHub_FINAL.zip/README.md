# Quantum Reality Proof Kit

This project simulates and visually proves foundational quantum phenomena using Python code.

## 🔬 Phenomena Simulated
- **Double-Slit Experiment** (Wave–Particle Duality)
- **Bloch Sphere** (Qubit Superposition)
- **Bell State** (Entanglement)
- **Quantum Tunneling** (Barrier Penetration)

## 📄 What's Included
- `quantum_master_demo.py` – The full simulation script
- `Quantum_Reality_ProofKit_WithFindings.pdf` – Final summary report with visuals
- Example output images (if available)

## 💡 Why This Matters
This project makes quantum behavior visible and replicable using only code — no lab required. It's an accessible proof of quantum reality for educators, students, and enthusiasts. It bridges programming with real physics experiments that historically redefined science.

## 🧠 Requirements
- Python 3.9+
- Libraries: qiskit, qiskit-aer, numpy, matplotlib, qutip

## 📚 License
MIT License — open for learning, teaching, and modification.

## 🔗 Learn More
Read the full explanation and results in the PDF report.
